const global = {
    owner: [6493353976], // GANTI PAKE ID TELE MU YA GANTENG 
    botToken: "7572177283:AAFGIjI4HTNeC9mO8ap3dTR8yugnVUY1Ydc", // ISI BOT TOKEN LU YAK
}

module.exports = global;
// CRACK BY VINNTHEXDC 
// https://whatsapp.com/channel/0029VavOzFy8KMqqMvMnOW1k